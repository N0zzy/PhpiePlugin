﻿namespace PhpieLanguageServer.Methods;

public class ConnectMethod: BaseMethod, IMethod
{
    public void Execute()
    {
      
    }
}