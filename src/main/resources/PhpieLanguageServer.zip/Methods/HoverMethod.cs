﻿namespace PhpieLanguageServer.Methods;

public class HoverMethod: BaseMethod, IMethod
{
    public void Execute()
    {
        
    }
}