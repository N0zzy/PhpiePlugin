﻿namespace PhpieLanguageServer.Methods;

public static class Method
{
    public const string 
        Connect = "connect",
        File = "file",
        Code = "code",
        Shutdown = "shutdown",
        Autocompletion = "autocompletion";
}