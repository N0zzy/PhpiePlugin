﻿namespace PhpieLanguageServer.Peachpie;

public class Errors
{
    public string Text { get; set; }
    public int Line { get; set; }
    public string Start { get; set; }
    public string End { get; set; }
}